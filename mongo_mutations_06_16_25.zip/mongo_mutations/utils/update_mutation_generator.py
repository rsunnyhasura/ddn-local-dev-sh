"""
Functions for generating MongoDB update mutation files.
"""
import os
from typing import Dict, Any, List

from scripts.mongo_mutations.utils.file_utils import save_json_file
from scripts.mongo_mutations.utils.insert_mutation_generator import _extract_scalar_type, _camel_to_lower


def _generate_field_name_variations(field_name: str) -> List[str]:
    """
    Generate different naming convention variations for a field name.

    Args:
        field_name: The original field name from schema (e.g., "FirstName")

    Returns:
        List of field name variations [snake_case, camelCase, original]
    """
    variations = []

    # Convert PascalCase to snake_case
    snake_case = ""
    for i, char in enumerate(field_name):
        if char.isupper() and i > 0:
            snake_case += "_"
        snake_case += char.lower()
    variations.append(snake_case)

    # Convert PascalCase to camelCase
    if field_name:
        camel_case = field_name[0].lower() + field_name[1:]
        variations.append(camel_case)

    # Original field name
    variations.append(field_name)

    # Remove duplicates while preserving order
    seen = set()
    unique_variations = []
    for variation in variations:
        if variation not in seen:
            seen.add(variation)
            unique_variations.append(variation)

    return unique_variations


def _generate_field_mapping_condition(schema_field_name: str, variations: List[str]) -> Dict[str, Any]:
    """
    Generate a $cond expression for mapping field name variations.

    Args:
        schema_field_name: The target field name in the schema
        variations: List of possible input field name variations

    Returns:
        MongoDB $cond expression
    """
    # Build nested $ifNull expressions for the variations
    def build_ifnull_chain(vars_list):
        if len(vars_list) == 1:
            return f"$$update.{vars_list[0]}"
        else:
            return {
                "$ifNull": [
                    f"$$update.{vars_list[0]}",
                    build_ifnull_chain(vars_list[1:])
                ]
            }

    ifnull_expr = build_ifnull_chain(variations)

    return {
        "$cond": {
            "if": {
                "$ne": [
                    {
                        "$ifNull": [ifnull_expr, None]
                    },
                    None
                ]
            },
            "then": ifnull_expr,
            "else": "$$REMOVE"
        }
    }


def generate_update_by_pk_mutation(collection_info: Dict[str, Any], output_dir: str) -> str:
    """
    Generate an update_by_pk mutation file.

    Args:
        collection_info: Collection information dictionary
        output_dir: Directory to save the mutation file

    Returns:
        Path to the generated file
    """
    collection_name = collection_info["collection_name"]
    fields = collection_info["fields"]

    # Create a result type name
    result_type_name = f"Update{collection_name}"

    # Generate arguments (id and fields to update)
    arguments = {
        "id": {
            "type": {
                "scalar": "objectId"
            }
        }
    }

    # Add all fields except _id as optional update fields
    for field_name, field_info in fields.items():
        if field_name == "_id":
            continue

        # Extract the type information
        type_info = field_info["type"]
        scalar_type = _extract_scalar_type(type_info)

        if scalar_type:
            if isinstance(type_info, str):
                arguments[_camel_to_lower(field_name)] = {
                    "type": type_info
                }
            else:
                arguments[_camel_to_lower(field_name)] = {
                    "type": {
                        "nullable": {
                            "scalar": scalar_type
                        }
                    }
                }

    # Generate $set operations with conditional logic
    set_operations = {}
    let_variables = {}

    for field_name, field_info in fields.items():
        if field_name == "_id":
            continue

        # Create template variable name
        var_name = _camel_to_lower(field_name)

        # Add to let variables
        let_variables[var_name] = f"{{{{ {var_name} }}}}"

        # Create conditional $set operation for this field
        set_operations[field_name] = {
            "$cond": {
                "if": {"$ne": [f"$${var_name}", None]},
                "then": f"$${var_name}",
                "else": f"${field_name}"
            }
        }

    # Create the mutation
    mutation = {
        "name": f"update{collection_name}ById",
        "description": f"Update a {collection_name} document by ID",
        "resultType": {
            "object": result_type_name
        },
        "arguments": arguments,
        "objectTypes": {
            result_type_name: {
                "fields": {
                    "ok": {
                        "type": {
                            "scalar": "int"
                        }
                    },
                    "n": {
                        "type": {
                            "scalar": "int"
                        }
                    }
                }
            }
        },
        "command": {
            "update": collection_name,
            "updates": [
                {
                    "q": {"_id": "{{ id }}"},
                    "u": [
                        {
                            "$set": set_operations
                        }
                    ]
                }
            ],
            "let": let_variables
        }
    }

    filepath = os.path.join(output_dir, f"update_{collection_name.lower()}_by_id.json")
    save_json_file(filepath, mutation)
    return filepath


def generate_flexible_update_mutation(collection_info: Dict[str, Any], output_dir: str) -> str:
    """
    Generate a flexible update mutation file with filter and extendedJSON update.

    Args:
        collection_info: Collection information dictionary
        output_dir: Directory to save the mutation file

    Returns:
        Path to the generated file
    """
    collection_name = collection_info["collection_name"]
    fields = collection_info["fields"]

    # Create type names
    result_type_name = f"Update{collection_name}Result"
    filter_type_name = f"Update{collection_name}Filter"

    # Generate filter fields (all fields as nullable)
    filter_fields = {}
    for field_name, field_info in fields.items():
        # Extract the type information
        type_info = field_info["type"]
        scalar_type = _extract_scalar_type(type_info)

        if scalar_type:
            if isinstance(type_info, str):
                filter_fields[field_name] = {
                    "type": type_info
                }
            else:
                filter_fields[field_name] = {
                    "type": {
                        "nullable": {
                            "scalar": scalar_type
                        }
                    }
                }

    # Generate $set pipeline with field name variation mapping
    set_operations = {}
    for field_name, field_info in fields.items():
        # Skip _id field for updates
        if field_name == "_id":
            continue

        # Generate field name variations
        variations = _generate_field_name_variations(field_name)

        # Generate the conditional mapping for this field
        set_operations[field_name] = _generate_field_mapping_condition(field_name, variations)

    # Create the mutation with pipeline
    mutation = {
        "name": f"update{collection_name}",
        "description": f"Update {collection_name} documents with flexible field name mapping",
        "resultType": {
            "object": result_type_name
        },
        "arguments": {
            "filter": {
                "type": {
                    "object": filter_type_name
                }
            },
            "update": {
                "type": "extendedJSON"
            }
        },
        "objectTypes": {
            result_type_name: {
                "fields": {
                    "ok": {
                        "type": {
                            "scalar": "int"
                        }
                    },
                    "n": {
                        "type": {
                            "scalar": "int"
                        }
                    }
                }
            },
            filter_type_name: {
                "fields": filter_fields
            }
        },
        "command": {
            "update": collection_name,
            "updates": [
                {
                    "q": "{{ filter }}",
                    "u": [
                        {
                            "$set": set_operations
                        }
                    ],
                    "multi": True
                }
            ],
            "let": {
                "update": "{{ update }}"
            }
        }
    }

    filepath = os.path.join(output_dir, f"update_{collection_name.lower()}.json")
    save_json_file(filepath, mutation)
    return filepath
