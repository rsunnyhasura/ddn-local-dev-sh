#!/usr/bin/env python3
"""
MongoDB Mutation Generator

This script generates mutation files for MongoDB collections based on schema definitions.
It automatically fixes null scalar types in schema files by replacing them with extendedJSON
before generating the mutations.
"""
import sys
import argparse
import json
from typing import List, Dict, Any

from scripts.mongo_mutations.utils.file_utils import load_json_file, list_json_files, ensure_directory_exists, save_json_file
from scripts.mongo_mutations.utils.schema_utils import extract_collection_info
from scripts.mongo_mutations.utils.mutation_generator import generate_all_mutations_for_collection

# Default directories
DEFAULT_SCHEMA_DIR = "app/connector/mongo/schema"
DEFAULT_OUTPUT_DIR = "app/connector/mongo/native_mutations"


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Generate MongoDB mutation files from schema definitions")
    parser.add_argument(
        "--schema-dir",
        default=DEFAULT_SCHEMA_DIR,
        help=f"Directory containing schema JSON files (default: {DEFAULT_SCHEMA_DIR})"
    )
    parser.add_argument(
        "--output-dir",
        default=DEFAULT_OUTPUT_DIR,
        help=f"Directory to save generated mutation files (default: {DEFAULT_OUTPUT_DIR})"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    return parser.parse_args()


def replace_null_types_recursive(obj: Any) -> Any:
    """
    Recursively replace {"scalar": "null"} with "extendedJSON" in a JSON object.

    Args:
        obj: The object to process (can be dict, list, or primitive)

    Returns:
        The processed object with null scalar types replaced
    """
    if isinstance(obj, dict):
        # Check if this is the pattern we want to replace
        if obj == {"scalar": "null"}:
            return "extendedJSON"

        # If it's a type field with the null scalar pattern
        if "type" in obj and obj["type"] == {"scalar": "null"}:
            new_obj = obj.copy()
            new_obj["type"] = "extendedJSON"
            return new_obj

        # Recursively process all dictionary values
        return {key: replace_null_types_recursive(value) for key, value in obj.items()}

    elif isinstance(obj, list):
        # Recursively process all list items
        return [replace_null_types_recursive(item) for item in obj]

    else:
        # Return primitive values unchanged
        return obj


def fix_null_types_in_schema(schema_filepath: str, verbose: bool = False) -> bool:
    """
    Fix null scalar types in a schema file by replacing them with extendedJSON.

    Args:
        schema_filepath: Path to the schema JSON file
        verbose: Whether to print verbose output

    Returns:
        True if the file was modified, False otherwise
    """
    if verbose:
        print(f"Checking schema file for null types: {schema_filepath}")

    try:
        # Load the original schema
        original_schema = load_json_file(schema_filepath)

        # Process the schema to replace null types
        modified_schema = replace_null_types_recursive(original_schema)

        # Check if any changes were made
        if original_schema != modified_schema:
            # Save the modified schema back to the file
            save_json_file(schema_filepath, modified_schema)
            if verbose:
                print(f"  ✓ Updated null scalar types in {schema_filepath}")
            return True
        else:
            if verbose:
                print(f"  - No null scalar types found in {schema_filepath}")
            return False

    except Exception as e:
        print(f"Error processing schema file {schema_filepath}: {e}")
        return False


def fix_null_types_in_all_schemas(schema_dir: str, verbose: bool = False) -> int:
    """
    Fix null scalar types in all schema files in the specified directory.

    Args:
        schema_dir: Directory containing schema JSON files
        verbose: Whether to print verbose output

    Returns:
        Number of files that were modified
    """
    schema_files = list_json_files(schema_dir)

    if not schema_files:
        print(f"No schema files found in {schema_dir}")
        return 0

    if verbose:
        print(f"Found {len(schema_files)} schema files to check")

    modified_count = 0
    for schema_filepath in schema_files:
        if fix_null_types_in_schema(schema_filepath, verbose):
            modified_count += 1

    return modified_count


def process_schema_file(schema_filepath: str, output_dir: str, verbose: bool = False) -> List[str]:
    """
    Process a single schema file and generate mutation files.

    Args:
        schema_filepath: Path to the schema JSON file
        output_dir: Directory to save the mutation files
        verbose: Whether to print verbose output

    Returns:
        List of paths to the generated files
    """
    if verbose:
        print(f"Processing schema file: {schema_filepath}")

    try:
        schema_json = load_json_file(schema_filepath)
        collection_info = extract_collection_info(schema_json)

        if verbose:
            print(f"  Collection: {collection_info['collection_name']}")
            print(f"  Object type: {collection_info['object_type']}")

        generated_files = generate_all_mutations_for_collection(collection_info, output_dir)

        if verbose:
            print(f"  Generated {len(generated_files)} mutation files")

        return generated_files

    except Exception as e:
        print(f"Error processing schema file {schema_filepath}: {e}")
        return []


def generate_all_mutations(schema_dir: str, output_dir: str, verbose: bool = False) -> int:
    """
    Generate mutations for all JSON files in the schema folder.

    Args:
        schema_dir: Directory containing schema JSON files
        output_dir: Directory to save generated mutation files
        verbose: Whether to print verbose output

    Returns:
        Number of generated mutation files
    """
    ensure_directory_exists(output_dir)

    schema_files = list_json_files(schema_dir)

    if not schema_files:
        print(f"No schema files found in {schema_dir}")
        return 0

    if verbose:
        print(f"Found {len(schema_files)} schema files")

    total_generated = 0
    for schema_filepath in schema_files:
        generated_files = process_schema_file(schema_filepath, output_dir, verbose)
        total_generated += len(generated_files)

    return total_generated


def main():
    """Main entry point."""
    args = parse_arguments()

    if args.verbose:
        print(f"Schema directory: {args.schema_dir}")
        print(f"Output directory: {args.output_dir}")

    try:
        # Always fix null scalar types first
        if args.verbose:
            print("Step 1: Fixing null scalar types in schema files...")
        modified_count = fix_null_types_in_all_schemas(args.schema_dir, args.verbose)
        if modified_count > 0:
            print(f"Updated {modified_count} schema files with null scalar type fixes")
        elif args.verbose:
            print("No null scalar types found to fix")

        # Then generate mutations using the updated schemas
        if args.verbose:
            print("Step 2: Generating mutations from updated schemas...")
        num_generated = generate_all_mutations(args.schema_dir, args.output_dir, args.verbose)
        print(f"Successfully generated {num_generated} mutation files")
        return 0
    except Exception as e:
        print(f"Error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())