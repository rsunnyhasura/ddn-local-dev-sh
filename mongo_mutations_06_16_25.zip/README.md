# Deployment Workflow

## Workspace
1. Delete all schema, native_mutations in app/connector/<connector_name> folder
2. Delete all hml files in app/metadata folder **except for <connector_name>.hml**
3. Introspect connector `ddn connector introspect <connector_name>`
4. Download schema files to local

## Local
5. Run python script `python -m scripts.mongo_mutations.mutations --schema-dir <path_to_schema_files> --output-dir <path_to_output_dir>`
6. Upload native mutations to workspace

## Workspace
7. Introspect connector `ddn connector introspect <connector_name>`
8. Track models, commands, relationships `ddn model add <connector_name> '*' && ddn command add <connector_name> '*' && ddn relationship add <connector_name> '*'`

## Local
9. Build and deploy connector

## Workspace
10. Supergraph build create no build connector `ddn supergraph build create --no-build-connectors`