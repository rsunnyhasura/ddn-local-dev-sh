# **MongoDB Update Mutations**

## **Key Questions & Analysis**

### **1\. Update Scope and Granularity**

**Primary Question**: What is the typical scope of updates performed on documents?

Based on the sample configuration data, we need to understand:

* Do users primarily update entire nested objects?  
* Are updates typically focused on specific fields?  
* How often are partial updates performed versus complete object replacements?  
  * Partial on root fields  
  * Partial on nested fields

**Sample Scenarios**:

```javascript
// Scenario A: Granular field updates
// Updating a single feature flag
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "id_strat_program_referrals" },
    "u": { "$set": { "cnfgVal.featureEnabled": true } }
  }]
}

// Scenario B: Nested object updates  
// Updating banner widget configuration
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "prism_member_banner_widget" },
    "u": { "$set": { 
      "cnfgVal.additionalDrawerBehaviour": "modal",
      "cnfgVal.cbmsCallEnabled": true 
    }}
  }]
}

// Scenario C: Complete object replacement
// Replacing entire configuration value
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "care_plan" },
    "u": { "$set": { "cnfgVal": { "newStructure": "completely different" } } }
  }]
}
```

### **2\. Nested Object Modification Patterns**

**Primary Question**: How frequently and extensively are deeply nested objects modified?

**Analysis Points**:

* Frequency of updates to nested structures like `cnfgVal.topFive`  
* Common patterns for modifying object hierarchies

**Sample Scenarios**:

```javascript
// Deep nested updates - modifying position values
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "prism_member_banner_widget" },
    "u": { "$set": { 
      "cnfgVal.topFive.phone.position.$numberInt": "2",
      "cnfgVal.topFive.subscriberId.position.$numberInt": "1"
    }}
  }]
}

// Adding new nested properties
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "prism_member_banner_widget" },
    "u": { "$set": { "cnfgVal.topFive.newField": { "label": "New Field", "position": { "$numberInt": "6" } } } }
  }]
}
```

### **3\. Array Operations and Management**

**Primary Question**: What are the common patterns for array modifications within documents?

**Analysis Points**:

* Frequency of array element additions/removals  
* Updates to specific array indices  
* Array reordering operations  
* Bulk array modifications

**Sample Scenarios**:

```javascript
// Adding to arrays
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "prism_member_banner_widget" },
    "u": { "$push": { "cnfgVal.additionalTabs": "newTab" } }
  }]
}

// Removing from arrays
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "prism_member_banner_widget" },
    "u": { "$pull": { "cnfgVal.additionalTabs": "eligibility" } }
  }]
}

// Updating specific array elements
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "prism_member_banner_widget" },
    "u": { "$set": { "cnfgVal.additionalTabs.0": "updatedFirstTab" } }
  }]
}
```

### **4\. Atomic Operations and Field Incrementing**

**Primary Question**: How often are atomic operations (increment, decrement, etc.) used?

**Sample Scenarios**:

```javascript
// Incrementing numeric values
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "um-edi-functions" },
    "u": { "$inc": { "cnfgVal": 5 } }
  }]
}

// Incrementing nested numeric values
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "care_plan" },
    "u": { "$inc": { 
      "cnfgVal.goalType.shortTerm.$numberInt": 1,
      "cnfgVal.goalType.longTerm.$numberInt": 2
    }}
  }]
}
```

### **5\. Root-Level vs. Nested Field Updates**

**Primary Question**: What is the distribution between root-level field updates and nested field modifications?

**Analysis Points**:

* Frequency of `applNm` updates vs. `cnfgVal` modifications  
* Pattern of simultaneous root and nested updates

**Sample Scenarios**:

```javascript
// Root-level updates
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "sample_prd_bbh" },
    "u": { "$set": { "applNm": "updated_prd_bbh" } }
  }]
}

// Mixed root and nested updates
{
  "update": "sysCnfg",
  "updates": [{
    "q": { "applNm": "ovc_visits_ui" },
    "u": { "$set": { 
      "applNm": "ovc_visits_ui_v2",
      "cnfgVal.adhoc_appointment_optional_fields": false
    }}
  }]
}
```

# **Possible solution examples**

## **Solution 1: Proper Schema with Partial Root Updates**

**Approach**: Partial updates at root level only. Nested objects require full replacement.

**Scenario A: Feature flag update**

```json
// Input
{
  "filter": { "applNm": "id_strat_program_referrals" },
  "update": { 
    "cnfgVal": { "featureEnabled": true }
  }
}

// Pipeline
[
  { "$set": { "cnfgVal": { "featureEnabled": true } } }
]
```

**Scenario B: Banner widget update (full object required)**

```json
// Input
{
  "filter": { "applNm": "prism_member_banner_widget" },
  "update": {
    "cnfgVal": {
      "additionalDrawerBehaviour": "modal",
      "additionalTabs": ["contacts", "preferences"],
      "cbmsCallEnabled": true,
      "topFive": {
        "phone": { "label": "Phone", "position": { "$numberInt": "1" } }
      }
    }
  }
}

// Pipeline
[
  { "$set": { "cnfgVal": { /* full object from input */ } } }
]
```

---

## **Solution 2: Arbitrary JSON Input**

**Approach**: Accept any JSON structure, use pipeline for nested updates.

**Scenario A: Simple nested update**

```json
// Input
{
  "filter": { "applNm": "prism_member_banner_widget" },
  "update": {
    "additionalDrawerBehaviour": "modal",
    "cbmsCallEnabled": true
  }
}

// Pipeline
[
  {
    "$set": {
      "cnfgVal.additionalDrawerBehaviour": "modal",
      "cnfgVal.cbmsCallEnabled": true
    }
  }
]
```

**Scenario B: Array update**

```json
// Input
{
  "filter": { "applNm": "prism_member_banner_widget" },
  "update": {
    "additionalTabs": ["contacts", "preferences", "newTab"]
  }
}

// Pipeline
[
  { "$set": { "cnfgVal.additionalTabs": ["contacts", "preferences", "newTab"] } }
]
```

---

## **Solution 3: Specialized Root Nodes**

**Approach**: Purpose-built mutations for specific operations.

**Scenario A: Feature toggle**

```json
// Input
{
  "applNm": "id_strat_program_referrals",
  "enabled": true
}

// Pipeline
[
  { "$set": { "cnfgVal.featureEnabled": true } }
]
```

**Scenario B: Banner behavior**

```json
// Input
{
  "applNm": "prism_member_banner_widget",
  "behavior": "modal",
  "cbmsEnabled": false
}

// Pipeline
[
  {
    "$set": {
      "cnfgVal.additionalDrawerBehaviour": "modal",
      "cnfgVal.cbmsCallEnabled": false
    }
  }
]
```

**Scenario C: Increment goal months**

```json
// Input
{
  "applNm": "care_plan",
  "shortTermIncrement": 2,
  "longTermIncrement": 3
}

// Pipeline
[
  {
    "$set": {
      "cnfgVal.goalType.shortTerm.$numberInt": {
        "$toString": {
          "$add": [
            { "$toInt": "$cnfgVal.goalType.shortTerm.$numberInt" },
            2
          ]
        }
      },
      "cnfgVal.goalType.longTerm.$numberInt": {
        "$toString": {
          "$add": [
            { "$toInt": "$cnfgVal.goalType.longTerm.$numberInt" },
            3
          ]
        }
      }
    }
  }
]
```
