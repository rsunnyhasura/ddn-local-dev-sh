"""
Generator for config-based point update mutations.
"""
import os
import json
from typing import Dict, Any, List, Optional

from scripts.mongo_mutations.utils.file_utils import save_json_file, load_json_file


def load_point_update_config(config_path: str) -> List[str]:
    """
    Load the point update configuration from a JSON file.
    
    Args:
        config_path: Path to the configuration file
        
    Returns:
        List of field paths from the configuration
    """
    try:
        return load_json_file(config_path)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def parse_field_path(field_path: str) -> Dict[str, Any]:
    """
    Parse a field path like "sysCnfg.cnfgVal.additionalTabs" into components.
    
    Args:
        field_path: The field path string
        
    Returns:
        Dictionary with collection, field, and nested_fields
    """
    parts = field_path.split('.')
    if len(parts) < 2:
        raise ValueError(f"Invalid field path: {field_path}. Must have at least collection.field")
    
    collection = parts[0]
    field = parts[1]
    nested_fields = parts[2:] if len(parts) > 2 else []
    
    return {
        "collection": collection,
        "field": field,
        "nested_fields": nested_fields,
        "full_field_path": ".".join(parts[1:])  # Everything after collection
    }


def generate_mutation_name(collection: str, field: str, nested_fields: List[str]) -> str:
    """
    Generate the mutation file name based on collection and field path.
    
    Args:
        collection: Collection name
        field: Field name
        nested_fields: List of nested field names
        
    Returns:
        Mutation file name
    """
    name_parts = [collection.lower(), field.lower()]
    name_parts.extend([nf.lower() for nf in nested_fields])
    return f"update_{'_'.join(name_parts)}.json"


def generate_config_based_update_mutation(
    field_path: str, 
    collection_info: Dict[str, Any], 
    output_dir: str
) -> Optional[str]:
    """
    Generate a config-based point update mutation for a specific field.
    
    Args:
        field_path: The field path from config (e.g., "sysCnfg.cnfgVal")
        collection_info: Collection information dictionary
        output_dir: Directory to save the mutation file
        
    Returns:
        Path to the generated file, or None if collection doesn't match
    """
    try:
        parsed = parse_field_path(field_path)
        collection_name = collection_info["collection_name"]
        
        # Only generate if the collection matches
        if parsed["collection"] != collection_name:
            return None
            
        fields = collection_info["fields"]
        
        # Create type names with nested fields
        name_parts = [parsed['field'].title()]
        name_parts.extend([nf.title() for nf in parsed['nested_fields']])
        type_suffix = ''.join(name_parts)
        result_type_name = f"Update{collection_name}{type_suffix}Result"
        filter_type_name = f"Update{collection_name}{type_suffix}Filter"
        
        # Generate filter fields (reuse from flexible mutation logic)
        filter_fields = {}
        for field_name, field_info in fields.items():
            type_info = field_info["type"]
            scalar_type = _extract_scalar_type(type_info)
            
            if scalar_type:
                filter_fields[field_name] = {
                    "type": {
                        "nullable": {
                            "scalar": scalar_type
                        }
                    }
                }
        
        # Generate the mutation name with nested fields
        mutation_name = f"update{collection_name}{type_suffix}"

        # Create the mutation
        mutation = {
            "name": mutation_name,
            "description": f"Update {collection_name} documents - point update for {parsed['full_field_path']}",
            "resultType": {
                "object": result_type_name
            },
            "arguments": {
                "filter": {
                    "type": {
                        "object": filter_type_name
                    }
                },
                "update": {
                    "type": "extendedJSON"
                }
            },
            "objectTypes": {
                result_type_name: {
                    "fields": {
                        "ok": {
                            "type": {
                                "scalar": "int"
                            }
                        },
                        "n": {
                            "type": {
                                "scalar": "int"
                            }
                        }
                    }
                },
                filter_type_name: {
                    "fields": filter_fields
                }
            },
            "command": {
                "update": collection_name,
                "updates": [
                    {
                        "q": "{{ filter }}",
                        "u": [
                            {
                                "$set": {
                                    parsed["full_field_path"]: "{{ update }}"
                                }
                            }
                        ],
                        "multi": True
                    }
                ]
            }
        }
        
        # Generate filename
        filename = generate_mutation_name(
            parsed["collection"], 
            parsed["field"], 
            parsed["nested_fields"]
        )
        filepath = os.path.join(output_dir, filename)
        
        save_json_file(filepath, mutation)
        return filepath
        
    except Exception as e:
        print(f"Error generating config-based mutation for {field_path}: {e}")
        return None


def _extract_scalar_type(type_info: Dict[str, Any]) -> Optional[str]:
    """
    Extract scalar type from type information.
    
    Args:
        type_info: Type information dictionary
        
    Returns:
        Scalar type string or None
    """
    if "scalar" in type_info:
        return type_info["scalar"]
    elif "nullable" in type_info and "scalar" in type_info["nullable"]:
        return type_info["nullable"]["scalar"]
    return None


def generate_all_config_based_mutations(
    collection_info: Dict[str, Any], 
    output_dir: str,
    config_path: str = "scripts/mongo_mutations/config/point_update_config.json"
) -> List[str]:
    """
    Generate all config-based update mutations for a collection.
    
    Args:
        collection_info: Collection information dictionary
        output_dir: Directory to save the mutation files
        config_path: Path to the configuration file
        
    Returns:
        List of paths to the generated files
    """
    config_entries = load_point_update_config(config_path)
    generated_files = []
    
    for field_path in config_entries:
        filepath = generate_config_based_update_mutation(field_path, collection_info, output_dir)
        if filepath:
            generated_files.append(filepath)
    
    return generated_files
